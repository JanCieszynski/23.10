<?php
$mysqli = new mysqli('localhost', 'root', '', 'wynajem');
$query = "SELECT nazwa, cena FROM pokoje"; 
$result = $mysqli->query($query);
?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Wynajem pokoi</title>
    <link rel="stylesheet" href="styl2.css">
</head>
<body>
    <header>
        <h1>Pensjonat pod dobrym humorem</h1>
    </header>
    <div class="baner"></div>
    <div class="container">
        <section class="lewy">
            <a href="index.html">GŁÓWNA</a>
            <img src="1.jpeg" alt="pokoje">
        </section>
        <section class="srodkowy">
            <a href="cennik.php">CENNIK</a>
            <table>
                <tr>
                    <th>Usługa</th>
                    <th>Cena</th>
                </tr>
                <?php if ($result->num_rows > 0): ?>
                    <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo($row['nazwa']); ?></td>
                        <td><?php echo($row['cena']); ?></td>
                    </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="3">Brak danych do wyświetlenia.</td>
                    </tr>
                <?php endif; ?>
            </table>
        </section>
        <section class="prawy">
            <a href="kalkulator.html">KALKULATOR</a>
            <img src="3.jpeg" alt="pokoje">
        </section>
    </div>
    <footer>
        <p>Stronę opracował: 000000000000</p>
    </footer>
</body>
</html>
<?php
$mysqli->close();
?>